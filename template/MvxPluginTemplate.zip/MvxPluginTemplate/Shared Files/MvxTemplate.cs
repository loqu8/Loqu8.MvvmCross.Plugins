﻿using System;

namespace Loqu8.MvvmCross.Plugins.$safeprojectname$
{
    public class Mvx$safeprojectname$ : IMvx$safeprojectname$
    {        
        public Mvx$safeprojectname$()
        {
        }

        #region I$safeprojectname$

        #endregion I$safeprojectname$
    }
}
