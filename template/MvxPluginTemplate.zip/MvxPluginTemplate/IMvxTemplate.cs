﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loqu8.MvvmCross.Plugins.$safeprojectname$
{
    public interface IMvx$safeprojectname$
    {

    }
}
